package com.example.mailapp

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    private var main: Account? = null
    private var tmp: Account? = null
    private var tmpExpiry = 0L
    private var creatingTmp = false
    private var settingUpMain = false
    private var askingName = false
    private var pendingName: String? = null
    private var pendingDomain: DomainInfo? = null
    private var ticks = 0

    private lateinit var statusView: TextView
    private lateinit var columns: LinearLayout
    private lateinit var mainPanel: LinearLayout
    private lateinit var tmpPanel: LinearLayout
    private lateinit var mainAddrView: TextView
    private lateinit var listMain: LinearLayout
    private lateinit var tmpIdleBox: LinearLayout
    private lateinit var tmpActiveBox: LinearLayout
    private lateinit var tmpAddrView: TextView
    private lateinit var tmpTimerView: TextView
    private lateinit var listTmp: LinearLayout

    private val colText = Color.parseColor("#EAF0FF")
    private val colMuted = Color.parseColor("#8FA8D8")
    private val colAccent = Color.parseColor("#6EC8FF")
    private val colCard = Color.parseColor("#15294F")
    private val colTmpCard = Color.parseColor("#1F2A5C")
    private val colBorder = Color.parseColor("#3C6FB8")
    private val colBtn = Color.parseColor("#234482")

    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private val ticker = object : Runnable {
        override fun run() {
            if (tmp != null) {
                if (System.currentTimeMillis() >= tmpExpiry) {
                    removeTmp("10-Minuten-Mail ist abgelaufen")
                } else {
                    updateTimer()
                }
            }
            ticks++
            if (ticks % 15 == 0) refreshAll()
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- Lebenszyklus ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("mail", Context.MODE_PRIVATE)
        loadState()
        buildUi()
        updateUi()
        if (main == null) askMainName()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayoutMode()
    }

    override fun onResume() {
        super.onResume()
        ticks = 14
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    // ---------- Speicher ----------

    private fun loadState() {
        val ma = prefs.getString("main_addr", null)
        val mp = prefs.getString("main_pass", null)
        if (ma != null && mp != null) {
            main = Account(
                ma,
                mp,
                prefs.getString("main_base", MailApi.BASE_TM) ?: MailApi.BASE_TM,
                prefs.getString("main_id", "") ?: ""
            )
        }
        val ta = prefs.getString("tmp_addr", null)
        val tp = prefs.getString("tmp_pass", null)
        if (ta != null && tp != null) {
            tmp = Account(
                ta,
                tp,
                prefs.getString("tmp_base", MailApi.BASE_TM) ?: MailApi.BASE_TM,
                prefs.getString("tmp_id", "") ?: ""
            )
            tmpExpiry = prefs.getLong("tmp_expiry", 0L)
        }
    }

    // ---------- UI-Helfer ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 16): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radius).toFloat()
        return d
    }

    private fun smallButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = dp(40)
        b.minimumHeight = dp(40)
        b.setTextColor(colText)
        b.background = rounded(colBtn, 12)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun accentButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.setTypeface(null, Typeface.BOLD)
        b.setTextColor(Color.parseColor("#06122B"))
        val g = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#8FD3FF"), Color.parseColor("#5AA0F0"))
        )
        g.cornerRadius = dp(14).toFloat()
        b.background = g
        b.setOnClickListener { onClick() }
        return b
    }

    private fun mlp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.rightMargin = dp(8)
        return lp
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 12f
        t.setTextColor(colMuted)
        return t
    }

    private fun addressText(): TextView {
        val t = TextView(this)
        t.textSize = 16f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(colText)
        t.setTextIsSelectable(true)
        return t
    }

    private fun sectionTitle(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 20f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(colText)
        return t
    }

    private fun card(color: Int): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = rounded(color)
        bg.setStroke(dp(1), colBorder)
        c.background = bg
        c.setPadding(dp(14), dp(12), dp(14), dp(10))
        return c
    }

    private fun scrollList(): Pair<ScrollView, LinearLayout> {
        val scroll = ScrollView(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        scroll.addView(box)
        return Pair(scroll, box)
    }

    // ---------- UI-Aufbau ----------

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#0A1630"), Color.parseColor("#12284F"))
        )
        root.setPadding(dp(16), dp(10), dp(16), dp(10))

        // Titelleiste
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ghost_logo)
        bar.addView(logo, LinearLayout.LayoutParams(dp(52), dp(52)))
        val appTitle = TextView(this)
        appTitle.text = "Ghost Mail"
        appTitle.textSize = 24f
        appTitle.setTypeface(null, Typeface.BOLD)
        appTitle.setTextColor(colText)
        val atp = LinearLayout.LayoutParams(WRAP, WRAP)
        atp.leftMargin = dp(6)
        bar.addView(appTitle, atp)
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(smallButton("↻ Aktualisieren") { refreshAll() })
        root.addView(bar)

        statusView = TextView(this)
        statusView.textSize = 12f
        statusView.setTextColor(colMuted)
        root.addView(statusView)

        // Zwei Spalten: links normale Mail, rechts 10-Minuten-Mail
        columns = LinearLayout(this)
        mainPanel = buildMainPanel()
        tmpPanel = buildTmpPanel()
        columns.addView(mainPanel)
        columns.addView(tmpPanel)
        root.addView(columns, LinearLayout.LayoutParams(MATCH, 0, 1f))

        setContentView(root)
        applyLayoutMode()
    }

    private fun buildMainPanel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL

        val c = card(colCard)
        c.addView(label("Deine dauerhafte Adresse"))
        mainAddrView = addressText()
        c.addView(mainAddrView)
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.addView(smallButton("Kopieren") { copy(main?.address) }, mlp())
        btns.addView(smallButton("Ändern") { onChangeMain() }, mlp())
        c.addView(btns)
        p.addView(c, LinearLayout.LayoutParams(MATCH, WRAP))

        val tl = LinearLayout.LayoutParams(WRAP, WRAP)
        tl.topMargin = dp(10)
        p.addView(sectionTitle("Posteingang"), tl)

        val sl = scrollList()
        listMain = sl.second
        p.addView(sl.first, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return p
    }

    private fun buildTmpPanel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL

        // Ohne aktive 10-Minuten-Mail
        tmpIdleBox = card(colTmpCard)
        tmpIdleBox.addView(label("10-Minuten-Mail"))
        val info = TextView(this)
        info.text = "Wegwerf-Adresse, die sich nach 10 Minuten selbst löscht."
        info.textSize = 14f
        info.setTextColor(colText)
        tmpIdleBox.addView(info)
        val createBtn = accentButton("⏱  10-Min-Mail erstellen") { onTmpClick() }
        val cb = LinearLayout.LayoutParams(MATCH, dp(52))
        cb.topMargin = dp(8)
        tmpIdleBox.addView(createBtn, cb)
        p.addView(tmpIdleBox, LinearLayout.LayoutParams(MATCH, WRAP))

        // Mit aktiver 10-Minuten-Mail
        tmpActiveBox = card(colTmpCard)
        tmpActiveBox.addView(label("10-Minuten-Adresse"))
        tmpAddrView = addressText()
        tmpActiveBox.addView(tmpAddrView)
        tmpTimerView = TextView(this)
        tmpTimerView.textSize = 14f
        tmpTimerView.setTextColor(colAccent)
        tmpActiveBox.addView(tmpTimerView)
        val tb = LinearLayout(this)
        tb.orientation = LinearLayout.HORIZONTAL
        tb.addView(smallButton("Kopieren") { copy(tmp?.address) }, mlp())
        tb.addView(smallButton("Neue") { onTmpClick() }, mlp())
        tb.addView(smallButton("Löschen") { removeTmp("10-Minuten-Mail gelöscht") }, mlp())
        tmpActiveBox.addView(tb)
        p.addView(tmpActiveBox, LinearLayout.LayoutParams(MATCH, WRAP))

        val tl = LinearLayout.LayoutParams(WRAP, WRAP)
        tl.topMargin = dp(10)
        p.addView(sectionTitle("Posteingang"), tl)

        val sl = scrollList()
        listTmp = sl.second
        p.addView(sl.first, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return p
    }

    // Breite Bildschirme (Tablet, Handy quer): nebeneinander. Schmale: untereinander.
    private fun applyLayoutMode() {
        val wide = resources.configuration.screenWidthDp >= 600
        val gap = dp(8)
        if (wide) {
            columns.orientation = LinearLayout.HORIZONTAL
            val a = LinearLayout.LayoutParams(0, MATCH, 1f)
            a.rightMargin = gap
            val b = LinearLayout.LayoutParams(0, MATCH, 1f)
            b.leftMargin = gap
            mainPanel.layoutParams = a
            tmpPanel.layoutParams = b
        } else {
            columns.orientation = LinearLayout.VERTICAL
            val a = LinearLayout.LayoutParams(MATCH, 0, 1f)
            a.bottomMargin = gap
            val b = LinearLayout.LayoutParams(MATCH, 0, 1f)
            b.topMargin = gap
            mainPanel.layoutParams = a
            tmpPanel.layoutParams = b
        }
    }

    private fun updateUi() {
        mainAddrView.text = main?.address ?: "Wird erstellt …"
        val t = tmp
        if (t != null) {
            tmpIdleBox.visibility = View.GONE
            tmpActiveBox.visibility = View.VISIBLE
            tmpAddrView.text = t.address
            updateTimer()
        } else {
            tmpIdleBox.visibility = View.VISIBLE
            tmpActiveBox.visibility = View.GONE
            showHint(listTmp, "Keine 10-Minuten-Mail aktiv.")
        }
    }

    private fun updateTimer() {
        val s = ((tmpExpiry - System.currentTimeMillis()) / 1000).coerceAtLeast(0L)
        tmpTimerView.text = String.format("Läuft ab in %02d:%02d", s / 60, s % 60)
    }

    private fun showHint(box: LinearLayout, text: String) {
        box.removeAllViews()
        val t = TextView(this)
        t.text = text
        t.setTextColor(colMuted)
        t.setPadding(0, dp(12), 0, 0)
        box.addView(t)
    }

    // ---------- Aktionen ----------

    private fun errorText(e: Exception): String {
        return if (e is ApiException) {
            "Server-Fehler " + e.code + ": " + (e.message ?: "").take(80)
        } else {
            "Fehler: " + e.javaClass.simpleName + ": " + (e.message ?: "").take(100)
        }
    }

    private fun copy(text: String?) {
        if (text == null) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("E-Mail", text))
        Toast.makeText(this, "Kopiert", Toast.LENGTH_SHORT).show()
    }

    private fun refreshAll() {
        val m = main
        if (m == null) retryMain() else refreshOne(m, listMain)
        val t = tmp
        if (t != null) refreshOne(t, listTmp)
    }

    private fun refreshOne(acc: Account, box: LinearLayout) {
        io.execute {
            try {
                val list = MailApi.messages(acc)
                ui.post {
                    if (acc === main || acc === tmp) {
                        showMails(acc, list, box)
                        statusView.text = ""
                    }
                }
            } catch (e: Exception) {
                ui.post { statusView.text = errorText(e) }
            }
        }
    }

    private fun showMails(acc: Account, list: List<Mail>, box: LinearLayout) {
        box.removeAllViews()
        if (list.isEmpty()) {
            showHint(box, "Noch keine Mails. Neue Nachrichten erscheinen hier automatisch.")
            return
        }
        for (m in list) {
            val c = card(colCard)
            val from = TextView(this)
            from.text = m.from
            from.textSize = 13f
            from.setTextColor(colMuted)
            from.maxLines = 1
            from.ellipsize = TextUtils.TruncateAt.END
            c.addView(from)
            val subj = TextView(this)
            subj.text = if (m.subject.isBlank()) "(kein Betreff)" else m.subject
            subj.textSize = 16f
            subj.setTypeface(null, if (m.seen) Typeface.NORMAL else Typeface.BOLD)
            subj.setTextColor(colText)
            c.addView(subj)
            val intro = TextView(this)
            intro.text = m.intro
            intro.textSize = 13f
            intro.setTextColor(colMuted)
            intro.maxLines = 2
            intro.ellipsize = TextUtils.TruncateAt.END
            c.addView(intro)
            val date = TextView(this)
            date.text = m.date.take(16).replace('T', ' ')
            date.textSize = 11f
            date.setTextColor(colMuted)
            c.addView(date)
            c.setOnClickListener { openMail(acc, m) }
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(8)
            box.addView(c, lp)
        }
    }

    private fun openMail(acc: Account, m: Mail) {
        io.execute {
            try {
                val d = MailApi.message(acc, m.id)
                var body = d.text
                if (body.isBlank() && d.html.isNotBlank()) {
                    body = HtmlCompat.fromHtml(d.html, HtmlCompat.FROM_HTML_MODE_LEGACY).toString()
                }
                val shown = "Von: " + d.from + "\n\n" + body.trim()
                ui.post {
                    AlertDialog.Builder(this)
                        .setTitle(if (d.subject.isBlank()) "(kein Betreff)" else d.subject)
                        .setMessage(shown)
                        .setPositiveButton("Schließen", null)
                        .show()
                }
            } catch (e: Exception) {
                ui.post { Toast.makeText(this, "Mail konnte nicht geladen werden", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    // ---------- Hauptadresse ----------

    private fun withDomains(onOk: (List<DomainInfo>) -> Unit, onFail: () -> Unit) {
        io.execute {
            try {
                val doms = MailApi.domains()
                ui.post { onOk(doms) }
            } catch (e: Exception) {
                ui.post {
                    statusView.text = errorText(e) + " – neuer Versuch folgt"
                    onFail()
                }
            }
        }
    }

    private fun showAddressDialog(
        title: String,
        message: String,
        allowEmpty: Boolean,
        cancelable: Boolean,
        doms: List<DomainInfo>,
        onOk: (String, DomainInfo) -> Unit,
        onCancel: () -> Unit
    ) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val input = EditText(this)
        input.hint = if (allowEmpty) "Name (leer = zufällig)" else "Name deiner Adresse"
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        input.setSingleLine()
        box.addView(input)
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            doms.map { "@" + it.domain }
        )
        box.addView(spinner)

        val builder = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setView(box)
            .setCancelable(cancelable)
            .setPositiveButton("OK", null)
        if (cancelable) {
            builder.setNegativeButton("Abbrechen") { _, _ -> onCancel() }
        }
        val dlg = builder.create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = input.text.toString().trim().lowercase()
                val valid = (name.isEmpty() && allowEmpty) ||
                    Regex("^[a-z0-9._-]{3,30}$").matches(name)
                if (!valid) {
                    input.error = "3–30 Zeichen: a–z, 0–9, Punkt, Unter- und Bindestrich"
                } else {
                    val dom = doms[spinner.selectedItemPosition]
                    dlg.dismiss()
                    onOk(name, dom)
                }
            }
        }
        dlg.show()
    }

    private fun askMainName() {
        if (askingName || settingUpMain) return
        askingName = true
        withDomains({ doms ->
            showAddressDialog(
                "Wähle deine Adresse",
                "Lege den Namen vor dem @ selbst fest. Lehnt eine Webseite die Adresse ab, wähle eine andere Domain.",
                false,
                false,
                doms,
                { name, dom ->
                    askingName = false
                    pendingName = name
                    pendingDomain = dom
                    setupMain(name, dom)
                },
                { askingName = false }
            )
        }, { askingName = false })
    }

    private fun retryMain() {
        val n = pendingName
        val d = pendingDomain
        if (n != null && d != null) setupMain(n, d) else askMainName()
    }

    private fun setupMain(name: String, domain: DomainInfo) {
        if (settingUpMain) return
        settingUpMain = true
        statusView.text = "Adresse wird erstellt …"
        io.execute {
            try {
                val acc = MailApi.createAccount(name, domain)
                prefs.edit()
                    .putString("main_addr", acc.address)
                    .putString("main_pass", acc.password)
                    .putString("main_id", acc.id)
                    .putString("main_base", acc.base)
                    .commit()
                ui.post {
                    main = acc
                    settingUpMain = false
                    pendingName = null
                    pendingDomain = null
                    statusView.text = ""
                    updateUi()
                    refreshOne(acc, listMain)
                }
            } catch (e: ApiException) {
                ui.post {
                    settingUpMain = false
                    if (e.code == 422) {
                        pendingName = null
                        pendingDomain = null
                        statusView.text = ""
                        Toast.makeText(
                            this,
                            "Dieser Name ist schon vergeben oder ungültig – bitte einen anderen wählen",
                            Toast.LENGTH_LONG
                        ).show()
                        askMainName()
                    } else {
                        statusView.text = errorText(e)
                    }
                }
            } catch (e: Exception) {
                ui.post {
                    settingUpMain = false
                    statusView.text = errorText(e)
                }
            }
        }
    }

    private fun onChangeMain() {
        val old = main ?: return
        AlertDialog.Builder(this)
            .setTitle("Adresse ändern?")
            .setMessage("Die bisherige Adresse und alle ihre Mails werden gelöscht.")
            .setPositiveButton("Weiter") { _, _ ->
                withDomains({ doms ->
                    showAddressDialog(
                        "Neue Adresse",
                        "Lege den Namen vor dem @ selbst fest. Lehnt eine Webseite die Adresse ab, wähle eine andere Domain.",
                        false,
                        true,
                        doms,
                        { name, dom -> changeMain(old, name, dom) },
                        {}
                    )
                }, {})
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun changeMain(old: Account, name: String, domain: DomainInfo) {
        statusView.text = "Adresse wird geändert …"
        io.execute {
            try {
                val acc = MailApi.createAccount(name, domain)
                prefs.edit()
                    .putString("main_addr", acc.address)
                    .putString("main_pass", acc.password)
                    .putString("main_id", acc.id)
                    .putString("main_base", acc.base)
                    .commit()
                ui.post {
                    main = acc
                    listMain.removeAllViews()
                    statusView.text = ""
                    updateUi()
                    refreshOne(acc, listMain)
                }
                try {
                    MailApi.deleteAccount(old)
                } catch (e: Exception) {
                }
            } catch (e: ApiException) {
                ui.post {
                    statusView.text = ""
                    val msg = if (e.code == 422) "Dieser Name ist schon vergeben oder ungültig" else errorText(e)
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                ui.post {
                    statusView.text = errorText(e)
                }
            }
        }
    }

    // ---------- 10-Minuten-Mail ----------

    private fun onTmpClick() {
        if (creatingTmp) return
        if (tmp != null) {
            AlertDialog.Builder(this)
                .setTitle("Neue 10-Minuten-Mail?")
                .setMessage("Die aktuelle 10-Minuten-Adresse wird gelöscht.")
                .setPositiveButton("Weiter") { _, _ -> askTmp() }
                .setNegativeButton("Abbrechen", null)
                .show()
        } else {
            askTmp()
        }
    }

    private fun askTmp() {
        withDomains({ doms ->
            showAddressDialog(
                "10-Minuten-Mail",
                "Eigener Name vor dem @ – oder leer lassen für einen zufälligen. Lehnt eine Webseite die Adresse ab, wähle eine andere Domain.",
                true,
                true,
                doms,
                { name, dom -> createTmp(name, dom) },
                {}
            )
        }, {})
    }

    private fun createTmp(name: String, domain: DomainInfo) {
        creatingTmp = true
        Toast.makeText(this, "10-Minuten-Mail wird erstellt …", Toast.LENGTH_SHORT).show()
        val old = tmp
        io.execute {
            try {
                val acc = MailApi.createAccount(name, domain)
                val exp = System.currentTimeMillis() + 10 * 60 * 1000L
                prefs.edit()
                    .putString("tmp_addr", acc.address)
                    .putString("tmp_pass", acc.password)
                    .putString("tmp_id", acc.id)
                    .putString("tmp_base", acc.base)
                    .putLong("tmp_expiry", exp)
                    .commit()
                ui.post {
                    tmp = acc
                    tmpExpiry = exp
                    creatingTmp = false
                    updateUi()
                    showHint(listTmp, "Warte auf Mails …")
                    refreshOne(acc, listTmp)
                }
                if (old != null) {
                    try {
                        MailApi.deleteAccount(old)
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Exception) {
                ui.post {
                    creatingTmp = false
                    val taken = e is ApiException && e.code == 422
                    val msg = if (taken) "Dieser Name ist schon vergeben oder ungültig" else errorText(e)
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun removeTmp(message: String) {
        val old = tmp ?: return
        tmp = null
        tmpExpiry = 0L
        prefs.edit()
            .remove("tmp_addr")
            .remove("tmp_pass")
            .remove("tmp_id")
            .remove("tmp_base")
            .remove("tmp_expiry")
            .apply()
        updateUi()
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        io.execute {
            try {
                MailApi.deleteAccount(old)
            } catch (e: Exception) {
            }
        }
    }
}
