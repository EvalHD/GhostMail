package com.example.mailapp

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom

class ApiException(val code: Int, message: String) : Exception(message)

class Account(
    val address: String,
    val password: String,
    var id: String = "",
    var token: String = ""
)

class Mail(
    val id: String,
    val from: String,
    val subject: String,
    val intro: String,
    val date: String,
    val seen: Boolean
)

class MailDetail(val from: String, val subject: String, val text: String, val html: String)

object MailApi {
    private const val BASE = "https://api.mail.tm"
    private const val CHARS = "abcdefghijklmnopqrstuvwxyz0123456789"
    private val rnd = SecureRandom()

    private fun random(n: Int): String {
        val sb = StringBuilder()
        repeat(n) { sb.append(CHARS[rnd.nextInt(CHARS.length)]) }
        return sb.toString()
    }

    private fun request(method: String, path: String, body: JSONObject?, token: String?): String {
        val conn = URL(BASE + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("Accept", "application/json")
            if (token != null && token.isNotEmpty()) {
                conn.setRequestProperty("Authorization", "Bearer $token")
            }
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiException(code, text)
            return text
        } finally {
            conn.disconnect()
        }
    }

    private fun authed(acc: Account, method: String, path: String): String {
        if (acc.token.isEmpty()) login(acc)
        return try {
            request(method, path, null, acc.token)
        } catch (e: ApiException) {
            if (e.code == 401) {
                login(acc)
                request(method, path, null, acc.token)
            } else {
                throw e
            }
        }
    }

    fun domains(): List<String> {
        val arr = JSONObject(request("GET", "/domains", null, null)).getJSONArray("hydra:member")
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) out.add(arr.getJSONObject(i).getString("domain"))
        if (out.isEmpty()) throw ApiException(0, "keine Domain verfuegbar")
        return out
    }

    // name leer = zufaelliger Name
    fun createAccount(name: String, domain: String): Account {
        val local = if (name.isBlank()) random(10) else name
        val address = "$local@$domain"
        val password = random(18)
        val body = JSONObject().put("address", address).put("password", password)
        val res = JSONObject(request("POST", "/accounts", body, null))
        val acc = Account(address, password, res.optString("id"))
        var last: Exception? = null
        repeat(3) {
            try {
                login(acc)
                return acc
            } catch (e: Exception) {
                last = e
                Thread.sleep(1000)
            }
        }
        throw last ?: ApiException(0, "Login fehlgeschlagen")
    }

    fun login(acc: Account) {
        val body = JSONObject().put("address", acc.address).put("password", acc.password)
        val res = JSONObject(request("POST", "/token", body, null))
        acc.token = res.getString("token")
        if (acc.id.isEmpty()) acc.id = res.optString("id")
    }

    private fun fromOf(o: JSONObject): String {
        val f = o.optJSONObject("from") ?: return ""
        val name = f.optString("name")
        val addr = f.optString("address")
        return if (name.isNotBlank()) "$name <$addr>" else addr
    }

    fun messages(acc: Account): List<Mail> {
        val arr = JSONObject(authed(acc, "GET", "/messages")).getJSONArray("hydra:member")
        val out = ArrayList<Mail>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                Mail(
                    o.optString("id"),
                    fromOf(o),
                    o.optString("subject"),
                    o.optString("intro"),
                    o.optString("createdAt"),
                    o.optBoolean("seen")
                )
            )
        }
        return out
    }

    fun message(acc: Account, id: String): MailDetail {
        val o = JSONObject(authed(acc, "GET", "/messages/$id"))
        val html = StringBuilder()
        val arr = o.optJSONArray("html")
        if (arr != null) {
            for (i in 0 until arr.length()) html.append(arr.optString(i))
        }
        return MailDetail(fromOf(o), o.optString("subject"), o.optString("text"), html.toString())
    }

    fun deleteAccount(acc: Account) {
        authed(acc, "DELETE", "/accounts/${acc.id}")
    }
}
